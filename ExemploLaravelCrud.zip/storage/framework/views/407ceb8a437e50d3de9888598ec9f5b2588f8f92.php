Pagina de Clientes

<a href='/clientes/cadastro'>Cadastrar Cliente</a><?php /**PATH C:\xampp\htdocs\LaravelEsqueleto\resources\views/clientes_listar.blade.php ENDPATH**/ ?>