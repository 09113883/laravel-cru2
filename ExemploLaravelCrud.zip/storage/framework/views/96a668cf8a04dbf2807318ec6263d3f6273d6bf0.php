


<?php $__env->startSection('conteudo'); ?>
    
    <div class="text-center">
        <h1>Bem-vindo à Página de Conteúdo</h1>
        <p>Esta é uma página de exemplo para demonstrar o uso de yield e extend no Laravel.</p>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrativo.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelEsqueleto\resources\views/administrativo/home.blade.php ENDPATH**/ ?>